// 获取accessToken
const config = require('../config.js')
const md5 = require('./md5.js')

var getAccessToken=function(uid) {

  
  return new Promise(function (resolve, reject) {
    let _timestamp = new Date().getTime().toString().substr(0, 10);
    console.log(uid)
    let str = `app_id=${config.service.serverAppId}&app_secret=${config.service.serverAppSecret}&timestamp=${_timestamp}&user_id=${uid}`
    let _signature = md5.hex_md5(str)
    // let _device_id = md5.hex_md5(_rand_str)
    const param = {
      timestamp: _timestamp,
      app_id: config.service.serverAppId,
      user_id: uid,
      signature: _signature,
    };
    wx.request({
      url: `${config.service.baseUrl}/buildtoken/getAccessToken`,
      method: 'POST',
      data: param,
      header: {
        'content-type': 'application/x-www-form-urlencoded', // 默认值
      },
      success: (res) =>{
        
        wx.setStorage({
          key: 'token',
          data: res.data.access_token,
        })
        
      },
      fail: function (res) {
        reject(res)
      }
    })
  })
}
module.exports = getAccessToken