const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()

  return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}
const getQuery = url=> { //获取url中"?"符后的字串
  var theQuery = new Object();
  if (url.indexOf("?") != -1) {
    var str = url.split("?")[1];
    if (url.indexOf("&") != -1) {
      strs = str.split("&");
      for (var i = 0; i < strs.length; i++) {
        theQuery[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
      }
    } else {
      theQuery[str.split("=")[0]] = unescape(str.split("=")[1]);
    }
  }
  return theQuery;
}
module.exports = {
  formatTime: formatTime,
  getQuery: getQuery
}
