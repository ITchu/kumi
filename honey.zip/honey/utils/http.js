const app = getApp()
const getAccessToken = require('./token.js')
// const Promise = require('./es6-promise.js')
const http = (url, data) => {
  let time;
  console.log(url)
  return new Promise(function (resolve, reject) {
    // var t = setInterval(res => {
      
    wx.request({
      url: `${app.globalData.baseUrl}${url}`,
      method: 'POST',
      data: data,
      header: {
        'content-type': 'application/x-www-form-urlencoded', // 默认值
        'token': app.globalData.token || '',
        'uid': app.globalData.uid || '',
        'rid': app.globalData.rid || '',
        'cid': app.globalData.cid || ''
      },

      success: function (res) {
        console.log(res)
        if (res.statusCode != 200) {
          reject({ error: '服务器忙，请稍后重试', code: 500 });
          return;
        }

        if (res.data.code == -902 || res.data.code == -901 || res.data.code == -903 || res.data.code == -200 || res.data.code == -904 || res.data.code == -905 || res.data.code == -906 || res.data.code == -901) {
          console.log(222)
          if (app.globalData.url.length == 1) {
            return false;
          } else {
            app.globalData.url.push(url);
            wx.removeStorage({
              key: 'token',
              success: (res) => {
                getAccessToken(app.globalData.uid);
                time = setInterval(() => {
                  wx.getStorage({
                    key: 'token',
                    success: (re) => {
                      app.globalData.token = re.data;
                      app.globalData.url = []
                      console.log(re)
                      if (re.data) {
                        console.log(res)
                        clearInterval(time)
                        wx.reLaunch({
                          url: '/pages/home/home',
                        })
                      }
                    }
                  })

                }, 1000)
              }
            })

          return;
          }
        }
       
        resolve(res.data);

      },
      fail: function (res) {
        // fail调用接口失败
        reject({ error: '网络错误', code: 0 });
      },
      complete: function (res) {
        // complete
      }
    })
    
    
  })
}

module.exports = http