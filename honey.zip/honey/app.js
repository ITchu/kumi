//app.js
const util = require('./utils/util.js')
const config = require('./config.js')
const md5 = require('./utils/md5.js')
App({
  onLaunch: function () {
    wx.getStorage({
      key: 'token',
      success: (res) => {
        console.log(res)
        this.globalData.token = res.data
      },
      fail:res=>{
        wx.setStorage({
          key: 'token',
          data: '',
        })
      }

    })
    wx.getStorage({
      key: 'uid',
      success: (res) => {
        console.log(res)
        this.globalData.uid = res.data
      },

    })
    
    // 登录
    wx.login({
      success: res => {
        console.log(res)
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
        if (res.code) {
          console.log(res.code)
          // wx.removeStorage({
          //   key: 'token',
          //   success: (resp) => {},
          // })
          // wx.showToast({
          //   title: '加载中',
          //   icon:'loading'
          // })
          this.globalData.code = res.code;

          wx.request({
            url: `${config.service.baseUrl}/login/getUser`,
            method: 'POST',
            data: {
              code: res.code
            },
            header: {
              'content-type': 'application/x-www-form-urlencoded', // 默认值
            },
            success: (res) => {
              let data = res.data;
              console.log(data)
              
              this.globalData.openid = res.data.data.openid;
              this.globalData.uid = res.data.data.uid;
              wx.setStorage({
                key: 'uid',
                data: res.data.data.uid,
              })
              if (res.data.data.uid!=0){
                wx.setStorage({
                  key: 'bindMobile',
                  data: '1',
                })
              }
             
              console.log(this.globalData)
             

            },
            fail: function (res) {
              console.log(res)
            }
          })


        }
      }
    })

  },

  globalData: {
    windowHeight:0,
    windowWidth:0,
    userInfo: '',
    phone: '',
    baseUrl: config.service.baseUrl,
    getToken: true,
    token: '',
    uid: 0,
    code: '',
    url: [],
    neddAddWx: 1, //是否需要添加微信信息
    needBindMobile: 1, //是否需要添加手机号
    openid: '',
    desk_no: '', //桌号
    rid: '', //推荐人id
    cid:"",//机构的id
    load: false, //是否是从搜索页
    goods:[],//创建订单的商品
    vip_order:0
  }
})