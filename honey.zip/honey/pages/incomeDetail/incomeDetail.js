// pages/incomeDetail/incomeDetail.js
const http = require('../../utils/http.js')
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    winHeight: "", //窗口高度
    currentTab: 0, //预设当前项的值
    scrollLeft: 0, //tab标题的滚动条位置
    titleList: [
      {
        id: 0,
        name: '全部'
      },
      {
        id: 1,
        name: '待付款'
      },
      {
        id: 2,
        name: '已付款'
      },
      {
        id: 3,
        name: '已发货'
      }
    ], //菜单列表,
    //菜单列表,
    contentDetail: [
    //   {
    //   cost_order: "11994.00",
    //   create_time: "2019-06-22 19:49:15",
    //   cost_rebate:'80.00',
    //   nickname:'555',
    //   endtime:0,
    //   goodsList: [
    //     {
    //       price: "1999.00",
    //       goods_id: 35,
    //       num: 6,
    //       price: "1999.00",
    //       product_id: 36,
    //       product_model: "T28S",
    //       product_name: "英得尔车载冰箱"
    //     }
    //   ],
    //   color_name: "白",
    //   cover: "https://robotapi.jitusoft.cn/Uploads/20190611/79f7abdec90f6321c12b892f88e97734.png",
    //   goods_id: 35,
    //   num: 6,
    //   price: "1999.00",
    //   product_id: 36,
    //   product_model: "T28S",
    //   product_name: "英得尔车载冰箱",
    //   order_id: "201906221949144103",
    //   status: 3,
    //   status_name: "已发货",
    //   sum_goods: 6
    // }
    ],
    currentPage: 1, //当前页数
    type: 0,
    total: 0,//总数
    swiperError: 0,
    currentIndex: 0,
  },
  //到底部加载
  lower() {
    if (this.data.currentPage >= this.data.total) {
      wx.showToast({ //如果全部加载完成了也弹一个框
        title: '我也是有底线的',
        icon: 'none',
        duration: 1000
      });
      return false;
    } else {
      this.getMore()
      wx.showLoading({ //期间为了显示效果可以添加一个过度的弹出框提示“加载中”  
        title: '加载中',
        icon: 'loading',
      });
      let t = setTimeout(() => {
        wx.hideLoading();
        clearTimeout(t)
      }, 1500)
    }
  },
  //获取更多内容
  getMore: function (e) {
    console.log(e);
    this.setData({
      currentPage: this.data.currentPage + 1
    })
    this.getContentInfo(this.data.titleList[this.data.currentTab].id)

  },
  changeGoodsSwip: function (detail) {
    console.log(detail)
    if (detail.detail.source == "touch") {
      //当页面卡死的时候，current的值会变成0 
      if (detail.detail.current == 0) {
        //有时候这算是正常情况，所以暂定连续出现3次就是卡了
        let swiperError = this.data.swiperError
        swiperError += 1
        this.setData({ swiperError: swiperError })
        if (swiperError >= 3) { //在开关被触发3次以上
          console.error(this.data.swiperError)
          this.setData({ currentTab: this.data.preIndex });//，重置current为正确索引
          this.setData({ swiperError: 0 })
        }
      } else {//正常轮播时，记录正确页码索引
        this.setData({ preIndex: detail.detail.current });
        //将开关重置为0
        this.setData({ swiperError: 0 })
      }
    }
  },
  //获取列表信息

  getContentInfo: function (type) {
    http('/shop/teamOrder', {
      status: type,
      page: this.data.currentPage,
      pageSize: 10
    }).then(res => {
      if(res.code==1){
        if (this.data.currentPage > 1) {
          let list = this.data.contentDetail;
          console.log(list)
          list = list.concat(res.data.list)
          this.setData({
            contentDetail: list
          })
        } else {
          this.setData({
            contentDetail: res.data.list,
            total: res.data.total
          })
        }
        if (this.data.currentPage < this.data.total) {
          this.setData({
            more: true
          })
        } else {
          this.setData({
            more: false
          })
        }
      }else if(res.code==-100){
        this.setData({
          title:res.msg,
          contentDetail:[]
        })
      }
      

    })
  },
  // 滚动切换标签样式
  switchTab: function (e) {
    console.log(e)
    var title = this.data.titleList,
      index = e.detail.current;
    if (this.data.currentTab == index) {
      return false;
    }
    this.setData({
      currentTab: e.detail.current,
      currentIndex: e.detail.current,
      currentPage: 1,
      type: e.detail.current
    });
    this.getContentInfo(this.data.titleList[e.detail.current].id);

    this.checkCor();
  },
  // 点击标题切换当前页时改变样式
  swichNav: function (e) {
    console.log(e)
    var cur = e.currentTarget.dataset.current;
    if (this.data.currentTab == cur) {
      return false;
    } else {
      this.setData({
        currentTab: cur,
        currentIndex: cur,
        currentPage: 1,
        type: cur
      })
      this.getContentInfo(this.data.titleList[cur].id);

    }
    this.checkCor();
  },
  //判断当前滚动超过一屏时，设置tab标题滚动条。
  checkCor: function () {
    if (this.data.currentTab >= 5) {
      this.setData({
        scrollLeft: 300
      })
    } else {
      this.setData({
        scrollLeft: 0
      })
    }
  },
  getwinHeight: function () {
    var that = this;
    //  高度自适应
    wx.getSystemInfo({
      success: (res) => {
        var clientHeight = res.windowHeight,
          clientWidth = res.windowWidth,
          rpxR = 750 / clientWidth;
        var calc = clientHeight * rpxR;
        console.log(calc)
        that.setData({
          winHeight: calc
        });
      }
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      navH: app.globalData.windowHeight
    })
    this.getwinHeight()
    this.getContentInfo(this.data.titleList[this.data.currentTab].id);
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})