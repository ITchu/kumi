// pages/extract/extract.js
const http=require('../../utils/http.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    money:0,//可提现金额
    withdrawNum:'',//提现金额
    nickname:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  all(){
    this.setData({
      withdrawNum:this.data.money
    })
  },
  onLoad: function (options) {
    this.setData({
      money:options.money,
      nickname:options.nickname
    })
  },
  withdraw(){
    if(!this.data.withdrawNum){
      wx.showToast({
        title: '请输入提现金额',
        icon:'none'
      })
      return false;
    } else if (this.data.withdrawNum * 1 > this.data.money*1){
      wx.showToast({
        title: '输入金额不能大于提现金额',
        icon: 'none'
      })
      return false;
    }else{
      http('/wallet/withdraw',{
        money: this.data.withdrawNum
      }).then(res=>{
        if(res.code==1){
          wx.showToast({
            title: res.msg,
            icon:'none'
          })
            wx.switchTab({
              url: '/pages/mine/mine',
            })
        }else{
          wx.showToast({
            title: res.msg,
            icon:'none'
          })
        }
      })
    }
  },
  setNum(event) {
    console.log(event)
    this.setData({
      withdrawNum: event.detail.value.replace(/\s+/g, ''),
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})