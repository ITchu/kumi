// pages/orderCheck/orderCheck.js
const http=require('../../utils/http.js')
const app=getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    goods:[],
    list:[],
    address:[]
  },
  toPay() {

    if (!this.data.list.address.address_id) {
      wx.showToast({
        title: '请选择地址',
        icon:'none'
      })
      return false
    }
    let goods = '';
    for (let i = 0; i < app.globalData.goods.length; i++) {
      goods += app.globalData.goods[i].goods_id + ',';
      goods += app.globalData.goods[i].num + '&';
    }
    goods = goods.slice(0, -1)
    if (app.globalData.vip_order == 1){
      http("/Order/create", {
        vip_order: 1,
        aid: this.data.list.address.address_id
      }).then(res => {
        console.log(res)
        if (res.code == 1) {
          
          this.toBuy(res.data.oid)
        } else {
          wx.showToast({
            title: res.msg,
            icon: 'none'
          })
        }
      })
    }else{
      http("/Order/create", {
        goods: goods,
        aid: this.data.list.address.address_id
      }).then(res => {
        console.log(res)
        if (res.code == 1) {
          this.toBuy(res.data.oid)
        } else {
          wx.showToast({
            title: res.msg,
            icon: 'none'
          })
        }
      })
    }
   
    // wx.navigateTo({
    //   url: '/pages/success/success',
    // })
  },
  toBuy(oid) {
    http("/Wechat/topay", {
      oid: oid,
      type: 'product_pay'
    }).then(res => {
      if (res.code == 1) {
        
        wx.requestPayment({
          'timeStamp': res.data.timeStamp,
          'nonceStr': res.data.nonceStr,
          'package': res.data.package,
          'signType': res.data.signType,
          'paySign': res.data.paySign,
          'success': resp => {
            wx.navigateTo({
              url: '/pages/orderDetail/orderDetail?id=' + oid,
            })
          },
          'fail': res => {
            wx.navigateTo({
              url: '/pages/orderDetail/orderDetail?id=' + oid,
            })
            console.log(res)
          }
        })
      } else {
        wx.showToast({
          title: res.msg,
          icon: 'none'
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      navH: app.globalData.windowHeight
    })
    
    console.log(options)
    if (options.addressInfo) {
      let  address = JSON.parse(options.addressInfo)
      this.setData({
        address:address 
      })
    }
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
    let goods='';
    for (let i = 0; i < app.globalData.goods.length;i++){
      goods += app.globalData.goods[i].goods_id+',';
      goods += app.globalData.goods[i].num+'&';
    }
    goods=goods.slice(0,-1)
    console.log(goods)
    if (app.globalData.vip_order==1){
      app.globalData.goods=[]
      http('/Order/confirm', {
        vip_order: 1
      }).then(res => {
        if (res.code == 1) {
          if (this.data.address.address_id) {
            res.data.address = this.data.address
          }
          this.setData({
            list: res.data
          })
        } else {
          wx.showToast({
            title: res.msg,
            icon: 'none'
          })
        }
      })
    }else{
      http('/Order/confirm', {
        goods: goods
      }).then(res => {
        if (res.code == 1) {
          if (this.data.address.address_id) {
            res.data.address = this.data.address
          }
          this.setData({
            list: res.data
          })
        } else {
          wx.showToast({
            title: res.msg,
            icon: 'none'
          })
        }
      })
    }
   
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    // app.globalData.vip_order=0;
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    // app.globalData.vip_order=0;
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})