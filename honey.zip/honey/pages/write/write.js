// pages/writeRefund/writeRefund.js
const http=require('../../utils/http.js')
const app=getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    oid:'',//订单id
    express:'',//快递公司
    express_no:'',//快递单号
  },
  
  bindExpress(e){
    this.setData({
      express: e.detail.value.replace(/\s+/g, ''),
    })
  },
  bindExpressNo(e){
    this.setData({
      express_no: e.detail.value.replace(/\s+/g, ''),
    })
  },

  //提交
  recommend() {
    console.log(this.data.express)
    if (!this.data.express){
      wx.showToast({
        title: '请填写物流公司',
        icon:'none'
      })
      return false;
    } else if (!this.data.express_no) {
      wx.showToast({
        title: '请填写物流单号',
        icon: 'none'
      })
      return false;
    }else{
      this.delivery()
    }
    
  },
  delivery() {
    http('/user/delivery', {
      oid: this.data.oid,
      express: this.data.express,
      express_no: this.data.express_no,
      type: 1
    }).then(res => {
      if (res.code == 1) {
        wx.navigateTo({
          url: '/pages/send/send',
        })
      } else {
        wx.showToast({
          title: res.msg,
          icon: 'none'
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      this.setData({
        oid:options.oid,
        price:options.price,
        navH: app.globalData.windowHeight
      })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})