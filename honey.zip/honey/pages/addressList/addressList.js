// pages/addresList/addressList.js
const http = require('../../utils/http.js')
let app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    addressList:[],
    wH:'',
    pageSize: 10,//
    page: 1,
    total: 1,
    address_id:'',//选中的地址
    index:-1,//选中地址在列表里的下标
    addressInfo:{},//选中地址对应的信息
    choose: false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      navH: app.globalData.windowHeight
    })
    if (options.choose) {
      this.setData({
        choose: true,
      
      })
    }
  },
  //确定收货地址
  sureAddress() {
    if (this.data.index<0){
      wx.showToast({
        title: '请选择收货地址',
        icon:'none'
      })
      return false;
    }
      let addressInfo = JSON.stringify(this.data.addressInfo);
      wx.navigateTo({
        url: '/pages/orderCheck/orderCheck?addressInfo=' + addressInfo,
      })
     
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      wH: wx.getSystemInfoSync().windowHeight
    })

    this.getAddressList()
  },
  lower() {
    if (this.data.page >= this.data.total / 10) {
      wx.showToast({ //如果全部加载完成了也弹一个框
        title: '我也是有底线的',
        icon: 'none',
        duration: 1000
      });
      return false;
    } else {
      this.getMore()
      wx.showLoading({ //期间为了显示效果可以添加一个过度的弹出框提示“加载中”  
        title: '加载中',
        icon: 'loading',
      });
      let t = setTimeout(() => {
        wx.hideLoading();
        clearTimeout(t)
      }, 1500)
    }
  },
  getMore() {
    let a = this.data.page;
    a++
    this.setData({
      page: a
    })
    this.getAddressList()
  },
  getAddressList(){
    http('/UserAddress/UserAddressList',{
      page:this.data.page,
      pageSize:this.data.pageSize
    }).then(res=>{
      if (res.code == 1) {
        if (this.data.page == 1) {
          this.setData({
            addressList: res.data.list,
            total: res.data.total
          })
        } else {
          let data = this.data.addressList;
          data = data.concat(res.data.list);
          this.setData({
            addressList: data,
          })
        }

      } else {
        wx.showToast({
          title: res.msg,
          icon: 'none'
        })
      }
    })
  },
  //选择地址
  chooseGuest(e) {
    console.log(e)
    let addressInfo = e.currentTarget.dataset.info;
    let num = e.currentTarget.dataset.index;
    this.setData({
      addressInfo: addressInfo,
      address_id: addressInfo.address_id,
      index: num
    })
  },
  //取消选择地址
  cannelChoose(e) {
      this.setData({
        addressInfo: {},
        address_id: '',
        index: -1
      })
  },
  setDefault(e) {
    console.log(e)
    let param=e.currentTarget.dataset.info;
    let index=e.currentTarget.dataset.index;
    http('/UserAddress/saveAddress', {
      'aid': param.address_id,
      'recevier': param.recevier,
      'mobile': param.mobile,
      'province': param.province,
      'city': param.city,
      'area': param.area,
      'address': param.address,
      'isdefault':1
    }).then(res => {
      if (res.code == 1) {
       
        let addressList = this.data.addressList;
        for (let i = 0; i < addressList.length;i++){
          addressList[i].isdefault=0
        }
   
        addressList[index].isdefault = 1
        
        this.setData({
          addressList: addressList
        })
        
        
        
      } else {
        wx.showToast({
          title: res.msg,
          icon: 'none'
        })
      }

    })
  },
  edit(e) {
    const _info = e.currentTarget.dataset.info
    console.log('edit ' + JSON.stringify(_info))
    wx.navigateTo({
      url: `../address/address?type=edit&info=${JSON.stringify(_info)}`
    })
  },
  delete(e) {
    const _id = e.currentTarget.dataset.id
    console.log('edit ' + _id)
    wx.showModal({
      title: '温馨提示',
      content: '确认删除该地址？',
      cancelText: '取消',
      confirmText: '删除',
      success: res => {
        if(res.confirm){
          http('/UserAddress/delUserAddress', {
            aid: _id
          }).then(res => {
            if (res.code == 1) {
              wx.showToast({
                title: '删除成功',
                icon: 'none'
              })
              this.getAddressList()
            } else {
              wx.showToast({
                title: res.msg,
                icon: 'none'
              })
            }
          })
        }
      }
    })
  },
  add() {
    console.log('add')
    wx.navigateTo({
      url: '../address/address?type=add'
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  // onShareAppMessage: function () {
  
  // }
})