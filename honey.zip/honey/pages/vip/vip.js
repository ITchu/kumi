// pages/vip/vip.js
const http=require('../../utils/http.js')
const app=getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    is_vip:false,
    info:{}
  },
  showVip(){
    app.globalData.vip_order=1
    wx.navigateTo({
      url: `/pages/orderCheck/orderCheck`,
    })
    // http('/user/getVipPayment').then(res=>{
    //   if(res.code==1){
    //     this.toBuy(res.data.oid)
    //   }else{
    //     wx.showToast({
    //       title: res.msg,
    //       icon:'none'
    //     })
    //   }
    // }) 
    
  },
  getInfo(){
    http('/user/userInfo').then(res => {
      if (res.code == 1) {
        this.setData({
          info: res.data
        })
        if (res.data.is_member>0){
          this.setData({
            is_vip:true
          })
        }
      } else {
        wx.showToast({
          title: res.msg,
          icon: 'none'
        })
      }
    })
  },
  toBuy(oid) {
    http("/Wechat/topay", {
      oid: oid,
      type: 'payment_pay'
    }).then(res => {
      if (res.code == 1) {
        wx.requestPayment({
          'timeStamp': res.data.timeStamp,
          'nonceStr': res.data.nonceStr,
          'package': res.data.package,
          'signType': res.data.signType,
          'paySign': res.data.paySign,
          'success': resp => {
            this.getInfo();
            
          },
          'fail': res => {

            console.log(res)
          }
        })
      } else {
        wx.showToast({
          title: res.msg,
          icon: 'none'
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    app.globalData.vip_order = 0
    this.getInfo()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    return {
      title: 'honey快乐哈利，智慧成长',
      path: 'pages/index/index?rid=' + app.globalData.uid,

    }
  }
})