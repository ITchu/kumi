//index.js
//获取应用实例
const app = getApp()
const http = require('../../utils/http.js');
const getToken = require('../../utils/token.js')
const util = require('../../utils/util.js')
Page({
  data: {
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    bindMobile: '',//是否已经绑定手机号 1 显示绑定手机号 
    rid: '',//推荐人id
    desk_no: '',//桌号
  },
  onLoad: function (options) {
    console.log(options)
    this.setData({
      navH: app.globalData.windowHeight
    })
    if (options.q) {
      let url = decodeURIComponent(options.q);
      console.log(url);
      let data = util.getQuery(url);
      if (data.uid) {

        app.globalData.rid = data.uid;
        this.setData({
          rid: data.uid
        })
      }
      if (data.code_id) {

        app.globalData.cid = data.code_id;

      }

    }
    if (options.rid) {
      app.globalData.rid = options.rid;
      this.setData({
        rid: options.rid
      })
    }
    wx.getStorage({
      key: 'uid',
      success: (res) => {
        app.globalData.uid = res.data
      },
    })
    // 获取用户信息
    wx.getSetting({
      success: res => {
        console.log(res)
        if (res.authSetting['scope.userInfo'] == true) {
          console.log(app.globalData.uid)
          wx.reLaunch({
            url: '/pages/home/home',
          })
          
 
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框




          // wx.getUserInfo({
          //   success: res => {
          //     // 可以将 res 发送给后台解码出 unionId
          //     this.globalData.userInfo = res.userInfo

          //     // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
          //     // 所以此处加入 callback 以防止这种情况
          //     if (this.userInfoReadyCallback) {
          //       this.userInfoReadyCallback(res)
          //     }
          //   }
          // })
        } else if (res.authSetting['scope.userInfo'] === false) {
          wx.showToast({
            title: '请先授权',
            icon: 'none'
          })
        }
      }
    })
  },
  onShow: function () {
  },
  getUserInfo: function (e) {
    console.log(e);
    if (e.detail.userInfo) {
      app.globalData.userInfo = e.detail.userInfo
      wx.setStorage({
        key: 'userInfo',
        data: e.detail.userInfo
      })
    wx.switchTab({
      url: '/pages/home/home',
    })
      // if (app.globalData.uid != 0) {
      //   wx.setStorage({
      //     key: 'bindMobile',
      //     data: '1',
      //   })
      //   wx.navigateTo({
      //     url: '/pages/home/home'
      //   })
      // }else{
      //   this.setData({
      //     bindMobile: 1
      //   })
      // }

    }



  }
})