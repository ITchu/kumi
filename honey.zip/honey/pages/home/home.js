// pages/home/home.js
const app = getApp();
const http = require('../../utils/http.js')
const config = require('../../config.js')
const getToken = require('../../utils/token.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    banner_array: [],//banner列表
    hot_array: [],//热销爆款
    pageSize: 10,//
    page: 1,
    list: [],
    height: '',
    total: 1,
    mobile: '',
    code: '',
    num: 1,
    phone:false,
    verify: ''
  },
  //获取验证码
  getCode() {
    let t;
    console.log(this.data.mobile)
    if (this.data.mobile && this.data.num == 11) {
      console.log('号码')
      http('/login/SendSms', {
        mobile: this.data.mobile
      }).then(res => {
        if (res.code == 1) {
          console.log(1)
          wx.showToast({
            title: '发送成功'
          })
          let number = 120;
          t = setInterval(() => {
            if (number == 0) {
              clearInterval(t);
              this.setData({
                second: ''
              })
              return;
            }
            this.setData({
              second: number
            })
            number--;
          }, 1000)
        } else {
          wx.showToast({
            title: res.data.msg,
            icon: 'none'
          })
        }
      })
    } else {
      wx.showToast({
        title: '请输入手机号码',
        icon: 'none'
      })

    }

  },
  //设置手机号
  setMobile(event) {
    console.log(event)
    this.setData({
      mobile: event.detail.value,
      num: event.detail.cursor
    })
  },
  //设置验证码
  setVerify(event) {
    console.log(event)
    this.setData({
      verify: event.detail.value,

    })
  },
  // 绑定
  binding(e) {

    console.log(e)
    // console.log(e.detail.value)
    if (!e.detail.value.phone.replace(/\s+/g, '')) {
      wx.showToast({
        title: '请输入手机号码',
        icon: 'none'
      })
    } else if (!e.detail.value.verify.replace(/\s+/g, '')) {
      wx.showToast({
        title: '请输入验证码',
        icon: 'none'
      })
    }
    else {
      this.toRegister()
    }
  },
  toRegister() {
    wx.getUserInfo({
      success: res => {
        console.log(res)
        http("/login/register", {
          openid: app.globalData.openid,
          mobile: this.data.mobile,
          verify: this.data.verify,
          nickName: res.userInfo.nickName,
          gender: res.userInfo.gender,
          avatarUrl: res.userInfo.avatarUrl,
          country: res.userInfo.country,
          province: res.userInfo.province,
          city: res.userInfo.city,

        }).then(res => {
          if (res.code == 1) {
            getToken(res.data.uid)

            app.globalData.uid = res.data.uid;
            wx.setStorage({
              key: 'uid',
              data: res.data.uid,
            })
            let t = setInterval(res => {
              wx.getStorage({
                key: 'token',
                success: (res) => {
                  clearInterval(t)
                  wx.showTabBar()
                  this.setData({
                    phone: true
                  })
                  this.getInfo();
                },
              })
            }, 1000)

          } else {
            wx.showToast({
              title: res.msg,
              icon: 'none'
            })
          }
        })
      }
    })
  },
  getGoodsInfo() {
    http('/product/lists', {
    
    }).then(res => {
      if (res.code == 1) {
        if (this.data.page == 1) {
          this.setData({
            list: res.data.list,
            total: res.data.total
          })
        } else {
          let data = this.data.list;
          data = data.concat(res.data.list);
          this.setData({
            list: data,
          })
        }

      } else {
        wx.showToast({
          title: res.msg,
          icon: 'none'
        })
      }
    })
    http('/')
  },
  goDetail(e) {
    wx.navigateTo({
      url: '/pages/goodsDetail/goodsDetail' ,
    })
  },
  getInfo(){
    http('/banner/index').then(res => {
      if (res.code == 1) {
        this.setData({
          banner_array: res.data,

        })
      } else {
        wx.showToast({
          title: res.msg,
          icon: 'none'
        })
      }
    })
    this.getGoodsInfo();
  },
  //banner图
  jumpClick: function (e) {
    var that = this;
    var index = e.currentTarget.dataset.current;
    console.log(index)
    var item = this.data.banner_array[index];
    console.log(item)
    if (item.url.length > 0) {
      app.globalData.bannerUrl = this.unescapeHTML(item.url);
      console.log(app.globalData.bannerUrl);
      wx.navigateTo({
        url: '/pages/active/active',
      })
    }
  },
  unescapeHTML: function (a) {
    a = "" + a;
    return a.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&apos;/g, "'");
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.showLoading({
      title: '加载中',
    })
    if (app.globalData.uid > 0) {
      this.setData({
        phone: true
      })
      wx.hideLoading({
        title: '加载中',
      })
      wx.showTabBar()
      console.log('存在uid')
      
    }
    else {
      wx.hideTabBar()
      this.setData({
        phone: false
      })
      wx.hideLoading({
        title: '加载中',
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    app.globalData.vip_order = 0;
    if(this.data.phone){
      this.getInfo()
    }

    wx.getSystemInfo({
      success: (res) => {
        this.setData({
          height: res.windowHeight
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})