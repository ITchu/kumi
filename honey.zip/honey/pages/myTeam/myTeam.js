// pages/myTeam/myTeam.js
const http=require('../../utils/http.js')
const app=getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    winHeight: "", //窗口高度
    currentTab: 0, //预设当前项的值
    scrollLeft: 0, //tab标题的滚动条位置
    currentPage: 1, //当前页数
    contentDetail:[
      // {
      //   create_time:"2019-06-14 08:11:43", 
      //   headimg:"/images/mine/touxiang@2x.png",
      //   nickname:"志彬",
      //   user_id:29,
      //   list:[
      //     {
      //       create_time: "2019-06-14 08:11:43",
      //       headimg: "/images/mine/touxiang@2x.png",
      //       nickname: "志彬",
      //       user_id: 29
      //     },
      //     {
      //       create_time: "2019-06-14 08:11:43",
      //       headimg: "/images/mine/touxiang@2x.png",
      //       nickname: "志彬",
      //       user_id: 29
      //     },
      //   ]
      // },
      // {
      //   create_time: "2019-06-14 08:11:43",
      //   headimg: "/images/mine/touxiang@2x.png",
      //   nickname: "志彬",
      //   user_id: 29
      // },
      // {
      //   create_time: "2019-06-14 08:11:43",
      //   headimg: "/images/mine/touxiang@2x.png",
      //   nickname: "志彬",
      //   user_id: 29
      // },
    ],
    more: false, //点击查看更多
    total: 0,//总数
    teamType:1,
    page:1,
    pageSize:10
  },
  choose(e) {
    this.setData({
      teamType: e.currentTarget.dataset.index,
      page:1
    })
    this.getTeamList()
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options)
    this.setData({
      num: options.num,
  
    })
  },
  //到底部加载
  lower() {
    if (this.data.currentPage >= this.data.total) {
      wx.showToast({ //如果全部加载完成了也弹一个框
        title: '我也是有底线的',
        icon: 'none',
        duration: 1000
      });
      return false;
    } else {
      this.getMore()
      wx.showLoading({ //期间为了显示效果可以添加一个过度的弹出框提示“加载中”  
        title: '加载中',
        icon: 'loading',
      });
      let t = setTimeout(() => {
        wx.hideLoading();
        clearTimeout(t)
      }, 1500)
    }
  },
  //获取更多内容
  getMore: function (e) {
    console.log(e);
    this.setData({
      currentPage: this.data.currentPage + 1
    })
    this.getTeamList()

  },
  getwinHeight: function () {
    var that = this;
    //  高度自适应
    wx.getSystemInfo({
      success: (res) => {
        var clientHeight = res.windowHeight,
          clientWidth = res.windowWidth,
          rpxR = 750 / clientWidth;
        var calc = clientHeight * rpxR;
        console.log(calc)
        that.setData({
          winHeight: calc
        });
      }
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  getTeamList(){
    http('/shop/teamList',{
      type: this.data.teamType,
      page:this.data.page,
      pageSize:this.data.pageSize
    }).then(res => {
      if (res.code == 1) {
        if(this.data.page>1){
          let list=this.data.contentDetail;
          list = list.concat(res.data.list)
          this.setData({
            contentDetail: list
          })
        }else{
          this.setData({
            contentDetail: res.data.list,
            total:res.data.total
          })
        }
       
      } else {
        wx.showToast({
          title: res.msg,
          icon: 'none'
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      
      page: 1,
      pageSize:10
    })
      this.getTeamList()
  
    
    this.getwinHeight()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})