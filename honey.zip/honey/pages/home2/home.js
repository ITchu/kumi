// pages/goodsDetail/goodsDetail.js
const http=require('../../utils/http.js')
const WxParse = require('../../utils/wxParse/wxParse.js')
const app=getApp()
const getToken=require('../../utils/token.js')
Page({ 

  /**
   * 页面的初始数据
   */
  data: {
      phone:false,
      isShow:false,
      pid:1,//产品id
      detail:{
        goodsList:[
          {
            id:1,
            color:'红色'
          },
          {
            id: 2,
            color: '绿色'
          }
        ]
      },
      index:0,//选中产品颜色的下标
      goods_id:1,//选中商品id
      num:1,//商品数量
      mobile: '',
      code: '',
      num: 1,
      verify: ''
  },
  //获取验证码
  getCode() {
    let t;
    console.log(this.data.mobile)
    if (this.data.mobile && this.data.num == 11) {
      console.log('号码')
      http('/login/SendSms', {
        mobile: this.data.mobile
      }).then(res => {
        if (res.code == 1) {
          console.log(1)
          wx.showToast({
            title: '发送成功'
          })
          let number = 120;
          t = setInterval(() => {
            if (number == 0) {
              clearInterval(t);
              this.setData({
                second: ''
              })
              return;
            }
            this.setData({
              second: number
            })
            number--;
          }, 1000)
        } else {
          wx.showToast({
            title: res.data.msg,
            icon: 'none'
          })
        }
      })
    } else {
      wx.showToast({
        title: '请输入手机号码',
        icon: 'none'
      })

    }

  },
  //设置手机号
  setMobile(event) {
    console.log(event)
    this.setData({
      mobile: event.detail.value,
      num: event.detail.cursor
    })
  },
  //设置验证码
  setVerify(event) {
    console.log(event)
    this.setData({
      verify: event.detail.value,
    
    })
  },
  // 绑定
  binding(e) {

    console.log(e)
    // console.log(e.detail.value)
    if (!e.detail.value.phone.replace(/\s+/g, '')) {
      wx.showToast({
        title: '请输入手机号码',
        icon: 'none'
      })
    } else if (!e.detail.value.verify.replace(/\s+/g, '')) {
      wx.showToast({
        title: '请输入验证码',
        icon: 'none'
      })
    }
    else {
      this.toRegister()
    }
  },
  toRegister(){
    wx.getUserInfo({
      success: res => {
        console.log(res)
        http("/login/register", {
          openid: app.globalData.openid,
          mobile:this.data.mobile,
          verify: this.data.verify,
          nickName: res.userInfo.nickName,
          gender: res.userInfo.gender,
          avatarUrl: res.userInfo.avatarUrl,
          country: res.userInfo.country,
          province: res.userInfo.province,
          city: res.userInfo.city,
         
        }).then(res => {
          if (res.code == 1) {
            getToken(res.data.uid)
         
            app.globalData.uid = res.data.uid;
            wx.setStorage({
              key: 'uid',
              data: res.data.uid,
            })
            let t = setInterval(res => {
              wx.getStorage({
                key: 'token',
                success: (res) => {
                  clearInterval(t)
                  this.setData({
                    phone:true
                  })
                 this.getInfo();
                },
              })
            }, 1000)

          } else {
            wx.showToast({
              title: res.msg,
              icon: 'none'
            })
          }
        })
      }
    })
  },
  //添加数量
  add(){
    // if (this.data.num>=this.data.detail.goodsList[this.data.index].store*1){
    //   wx.showToast({
    //     title: '该商品不能购买更多~',
    //     icon:'none'
    //   })
    //   return false;
    // }
    this.setData({
      num:this.data.num+1
    })
  },
  //减少数量
  reduce() {
    if (this.data.num < 2 ) {
      wx.showToast({
        title: '该商品不能再减少~',
        icon: 'none'
      })
      return false;
    }
    this.setData({
      num: this.data.num -1
    })
  },
  //展示规格弹窗
  showSpec: function () {
    this.setData({
      isShow: true,
      
    })
  },
  //去购买
  toBuy(){
    
    let data=[{
      goods_id: this.data.goods_id,
      num:this.data.num
    }];
    app.globalData.goods=data;
    this.setData({
      isShow:true
    })
    wx.navigateTo({
      url:  `/pages/orderCheck/orderCheck`,
    })
  },
  //关闭规格弹窗
  closeSpec: function () {
    this.setData({
      isShow: false,
      
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.showLoading({
      title: '加载中',
    })
    if (app.globalData.uid >0) {
      this.setData({
        phone: true
      })
      wx.hideLoading({
        title: '加载中',
      })
      wx.showTabBar()
      console.log('存在uid')
      this.getInfo();
    }
    else {
      this.setData({
        phone: false
      })
      wx.hideLoading({
        title: '加载中',
      })
    }
    // this.setData({
    //   navH: app.globalData.windowHeight
    // })
    // this.setData({
    //   pid:options.id
    // })
  },
  getInfo(){
    http('/product/detail').then(res => {
      if (res.code == 1) {
        this.setData({
          detail: res.data,
          goods_id: res.data.goodsList[0].goods_id
        })

        WxParse.wxParse('contents', 'html', res.data.content, this, 5);
   
      } else {
        wx.showToast({
          title: res.msg,
          icon: 'none'
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },
  //选择商品颜色
  chooseColor(e){
    this.setData({
      goods_id: e.currentTarget.dataset.id,
      index:e.currentTarget.dataset.index
    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    // return {
    //   title: '果养坊',
    //   path: '/pages/index/index',
    //   imageUrl: this.data.info.rec_qr //自定义图片路径，可以是本地文件路径、代码包文件路径或者网络图片路径。支持PNG及JPG。显示图片长宽比是 5:4。
    // }
  }
})