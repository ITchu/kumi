// pages/orderDetail/orderDetail.js
const http = require('../../utils/http.js')
const app=getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    order_id: '',//订单id
    detail: {
      address:{ 
        recevier: "ccc", 
        mobile: "15035482512",
        address: "山西省太原市小店区dddd" 
      },
    canceltime:0,
    cost_goods:"11994.00",
    cost_order: "11994.00",
    create_time:"2019-06-22 19:49:15",
    dlytime:"2019-06-22 19:50:16",
    endtime:0,
    express:"顺丰",
    express_no:"123456",
    goodsList:[
      { 
        color_name:"白",
        cover:"https://robotapi.jitusoft.cn/Uploads/20190611/79f7abdec90f6321c12b892f88e97734.png",
        goods_id:35,
        price: "1999.00",
        num: 6, 
        product_id: 36, 
        goods_id: 35,
        product_model:"T28S",
        product_name:"英得尔车载冰箱"
      }
    ],

    order_id:"201906221949144103",
    paytime:"2019-06-22 19:49:26",
    rcvtime:0,
    refund_time:0,
    status:3,
    status_name:"已发货",
    surplus_time:515313,
    },//订单详情
    time: '',//待付款状态的倒计时
    t: '',//定时器
  },
  //去退款
  toRefund(){
    wx.navigateTo({
      url: `/pages/writeRefund/writeRefund?oid=${this.data.order_id}&price=${this.data.detail.cost_order}`,
    })
  },
  toBuy() {
    http("/Wechat/topay", {
      oid: this.data.detail.order_id,
      type: 'product_pay'
    }).then(res => {
      if (res.code == 1) {


        wx.requestPayment({
          'timeStamp': res.data.timeStamp,
          'nonceStr': res.data.nonceStr,
          'package': res.data.package,
          'signType': res.data.signType,
          'paySign': res.data.paySign,
          'success': resp => {
            this.getDetail()
          },
          'fail': res => {

            console.log(res)
          }
        })
      } else {
        wx.showToast({
          title: res.msg,
          icon: 'none'
        })
      }
    })
  },
  //时间倒计时
  timeDown(totalSeconds) {
    console.log(1)
    //天数
    let days = Math.floor(totalSeconds / (60 * 60 * 24));
    //取模（余数）
    let modulo = totalSeconds % (60 * 60 * 24);
    //小时数
    let hours = Math.floor(modulo / (60 * 60));
    modulo = modulo % (60 * 60);
    //分钟
    let minutes = Math.floor(modulo / 60);//向下取整
    //秒
    var seconds = modulo % 60;
    //输出到页面
    if (totalSeconds >= 0) {
      let time = '订单付款将在' + minutes + "分" + seconds + "秒后自动关闭"
      this.setData({
        time: time,
        t: setTimeout(() => {
          this.timeDown(this.data.detail.surplus_time--);
        }, 1000)
      })

    }

  },
  //确认收货
  receive() {
    wx.showModal({
      title: '温馨提示',
      content: '请确保已经收到商品后，才点击确认收货',
      cancelText: '取消',
      confirmText: '确认收货',
      success: resp => {
        if (resp.confirm) {
          http('/user/receiveOrder', {
            oid: this.data.order_id,
          
          }).then(res => {
            if (res.code == 1) {
              this.getDetail()
            } else {
              wx.showToast({
                title: res.msg,
                icon: 'none'
              })
            }
          })
        }
      },
      fail: res => {

      }
    })
  },

  //获取订单详情
  getDetail() {
    http('/user/orderDetail', {
      oid: this.data.order_id
    }).then(res => {
      wx.hideLoading()
      if (res.code == 1) {
        if (res.data.status == 1) {
          this.timeDown(res.data.surplus_time)
        }
        this.setData({
          detail: res.data
        })
      } else {
        wx.showToast({
          title: res.msg,
          icon: 'none'
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      navH: app.globalData.windowHeight
    })
    // wx.showLoading({
    //   title: '加载中',
    // })
    this.setData({
      order_id: options.id
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // app.globalData.vip_order = 0;
    this.getDetail()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    clearTimeout(this.data.t)
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    clearTimeout(this.data.t)
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})