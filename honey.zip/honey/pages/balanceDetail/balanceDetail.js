// pages/balanceDetail/balanceDetail.js
const http=require('../../utils/http.js')
const app=getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    page:1,
    // month: ["2019年06月", "2019年05月", "2019年04月", "2019年03月"],
    month: [],
    index:0,
    contentDetail:{
      // "201906": {
      //   "month": "2019年06月",
      //   "list": [
      //     {
      //       "log_id": 10,
      //       "date": "20日",
      //       "amount": "+ ¥159.92",
      //       "money": "652.00",
      //       "type": "返利"
      //     }
      //   ]
      // },
      // "201905": {
      //   "month": "2019年06月",
      //   "list": [
      //     {
      //       "log_id": 10,
      //       "date": "20日",
      //       "amount": "+ ¥159.92",
      //       "money": "652.00",
      //       "type": "返利"
      //     },
      //     {
      //       "log_id": 10,
      //       "date": "20日",
      //       "amount": "+ ¥159.92",
      //       "money": "652.00",
      //       "type": "返利"
      //     }
      //   ]
      // }
    },
    page: 1,
    pageSize: 10,
    total:0
  },
  bindPickerChange(e){
    this.setData({
      index: e.detail.value,
      page: 1
    })
    this.getList(this.data.month[this.data.index])
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      navH: app.globalData.windowHeight
    })
    http('/Wallet/getMonth').then(res=>{
      if(res.code==1){
        if(res.data.length>0){
          this.setData({
            month: res.data,
          })
          this.getList(this.data.month[this.data.index])
          
        }else{
          this.setData({
            month: res.data,
            contentDetail: []
          })
        }
        
      }else{
        wx.showToast({
          title: res.msg,
          icon:'none'
        })
      }
    })
    
     
      //  高度自适应
      wx.getSystemInfo({
        success: (res) => {
          var clientHeight = res.windowHeight,
            clientWidth = res.windowWidth,
            rpxR = 750 / clientWidth;
          var calc = clientHeight * rpxR;
          console.log(calc)
          this.setData({
            winHeight: calc
          });
        }
      });
    
  },
  //到底部加载
  lower() {
    if (this.data.currentPage >= this.data.total) {
      wx.showToast({ //如果全部加载完成了也弹一个框
        title: '我也是有底线的',
        icon: 'none',
        duration: 1000
      });
      return false;
    } else {
      this.getMore()
      wx.showLoading({ //期间为了显示效果可以添加一个过度的弹出框提示“加载中”  
        title: '加载中',
        icon: 'loading',
      });
      let t = setTimeout(() => {
        wx.hideLoading();
        clearTimeout(t)
      }, 1500)
    }
  },
  //获取更多内容
  getMore: function (e) {
    console.log(e);
    this.setData({
      page: this.data.page + 1
    })
    this.getList(this.data.month[this.data.index])

  },

  //获取列表信息

  getList: function (type) {
    http('/Wallet/moneyDetail', {
      month: type,
      page: this.data.page,
      pageSize: this.data.pageSize
    }).then(res => {
      if (this.data.page > 1) {
        let list = this.data.contentDetail;
        console.log(list)
         
        for (let key in list) {
          for (let key2 in res.data.list){
            console.log(key);
            console.log(key2);
            if(key==key2){
              let temp = Object.assign([],res.data.list[key2].list);
              list[key].list=list[key].list.concat(temp)
    
              console.log(list[key].list)
            }else{
              list[key2] = res.data.list[key2]
            }
          }

        }  
        // list = list.concat(res.data.list)
        this.setData({
          contentDetail: list
        })
      } else {
        this.setData({
          contentDetail: res.data.list,
          total: res.data.total
        })
      }
      if (this.data.currentPage < this.data.total) {
        this.setData({
          more: true
        })
      } else {
        this.setData({
          more: false
        })
      }

    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})