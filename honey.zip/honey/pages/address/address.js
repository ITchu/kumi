// pages/address/address.js
const http = require('../../utils/http.js')
let app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    region: ['省', '市', '区'],
    // customItem: '^_^',
    info: '' // 上页拿到的数据
  },

  /**
   * 生命周期函数--监听页面加载
   */

  onLoad: function (opt) {
    this.setData({
      navH: app.globalData.windowHeight
    })
    console.log(opt)
    const _type = opt.type
    const _info = opt.info ? JSON.parse(opt.info) : ''
    wx.setNavigationBarTitle({
      title: _type == 'add' ? '新增地址' : '修改地址',
    })
    if(_type == 'edit'){
      this.setData({
        region: [_info.province, _info.city, _info.area]
      })
    }
    this.setData({
      type: _type,
      info: _info
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },
  bindRegionChange(e) {
    this.setData({
      region: e.detail.value
    })
  },

  formSubmit(e) {
    console.log(e.detail.value)
    const param = e.detail.value

    if (!param.recevier){
      wx.showToast({
        title: '请填写姓名',
        icon: 'none'
      })
      return false
    } else if (!param.mobile) {
      wx.showToast({
        title: '请填写手机号码',
        icon: 'none'
      })
      return false
    } else if (!/^[1][34578][0-9]{9}$/.test(param.mobile)) {
      wx.showToast({
        title: '请填写正确的手机号码',
        icon: 'none'
      })
      return false
    } else if (param.region[0].length < 2) {
      wx.showToast({
        title: '请选择省，市，区',
        icon: 'none'
      })
      return false
    } else if (!param.address) {
      wx.showToast({
        title: '请填写详细地址',
        icon: 'none'
      })
      return false
    } else if (param.address.length > 50) {
      wx.showToast({
        title: '详细地址不超过50个字',
        icon: 'none'
      })
      return false
    }

    if(this.data.type == 'add'){
      http('/UserAddress/saveAddress', {
        'recevier': param.recevier,
        'mobile': param.mobile,
        'province': param.region[0],
        'city': param.region[1],
        'area': param.region[2],
        'address': param.address
      }).then(res => {
        if(res.code == 1){
          wx.showToast({
            title: '添加成功',
            icon: 'none'
          })
          setTimeout(() => {
            wx.navigateBack()
          }, 1000)
        }else{
          wx.showToast({
            title: res.msg,
            icon: 'none'
          })
        }
      })
    } else if(this.data.type == 'edit'){
      http('/User/editUserAddress', {
        'aid': this.data.info.address_id,
        'recevier': param.recevier,
        'mobile': param.mobile,
        'province': param.region[0],
        'city': param.region[1],
        'area': param.region[2],
        'address': param.address
      }).then(res => {
        if (res.code == 1) {
          wx.showToast({
            title: '修改成功',
            icon: 'none'
          })
          setTimeout(() => {
            wx.navigateBack()
          }, 1000)
        }else{
          wx.showToast({
            title: res.msg,
            icon: 'none'
          })
        }
        
      })
    }
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  // onShareAppMessage: function () {
  
  // }
})